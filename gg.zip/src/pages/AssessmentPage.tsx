import { motion } from 'motion/react';
import { Brain, ArrowRight, Heart, CheckCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';

const phq9Questions = [
  "Little interest or pleasure in doing things",
  "Feeling down, depressed, or hopeless",
  "Trouble falling or staying asleep, or sleeping too much",
  "Feeling tired or having little energy",
  "Poor appetite or overeating",
  "Feeling bad about yourself — or that you are a failure or have let yourself or your family down",
  "Trouble concentrating on things, such as reading the newspaper or watching television",
  "Moving or speaking so slowly that other people could have noticed? Or the opposite — being so fidgety or restless that you have been moving around a lot more than usual",
  "Thoughts that you would be better off dead or of hurting yourself in some way"
];

const gad7Questions = [
  "Feeling nervous, anxious, or on edge",
  "Not being able to stop or control worrying",
  "Worrying too much about different things",
  "Trouble relaxing",
  "Being so restless that it is hard to sit still",
  "Becoming easily annoyed or irritable",
  "Feeling afraid, as if something awful might happen"
];

const responseOptions = [
  { label: "Not at all" },
  { label: "Several days" },
  { label: "More than half the days" },
  { label: "Nearly every day" }
];

const difficultyOptions = [
  "Not difficult at all",
  "Somewhat difficult",
  "Very difficult",
  "Extremely difficult"
];

export function AssessmentPage() {
  const navigate = useNavigate();
  const [phq9Answers, setPhq9Answers] = useState<number[]>(Array(9).fill(-1));
  const [gad7Answers, setGad7Answers] = useState<number[]>(Array(7).fill(-1));
  const [phq9Difficulty, setPhq9Difficulty] = useState<string>("");
  const [gad7Difficulty, setGad7Difficulty] = useState<string>("");

  const handlePhq9Answer = (questionIndex: number, value: number) => {
    const newAnswers = [...phq9Answers];
    newAnswers[questionIndex] = value;
    setPhq9Answers(newAnswers);
  };

  const handleGad7Answer = (questionIndex: number, value: number) => {
    const newAnswers = [...gad7Answers];
    newAnswers[questionIndex] = value;
    setGad7Answers(newAnswers);
  };

  const handleSubmit = async () => {
    // basic validation
    if (phq9Answers.includes(-1) || gad7Answers.includes(-1)) {
      alert("Please answer all questions before continuing.");
      return;
    }

    const token = localStorage.getItem("token");
    if (!token) {
      alert("Session expired. Please log in again.");
      navigate("/login");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/assessments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          phq9Answers,
          gad7Answers
          // you can also send difficulty if you later extend backend:
          // phq9Difficulty,
          // gad7Difficulty
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message || "Failed to submit assessment");
        return;
      }

      // On success go to dashboard
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
      alert("Something went wrong submitting your assessment.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-[#ED6962] relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div 
        className="absolute top-20 left-10 w-96 h-96 bg-teal-400/40 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.7, 0.5],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div 
        className="absolute bottom-20 right-10 w-96 h-96 bg-coral-400/50 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.6, 0.4, 0.6],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Header */}
      <header className="relative z-10 px-6 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-coral-400 to-coral-600 rounded-xl flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-white text-xl">MindMate</span>
            </motion.div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 py-8 pb-16">
        <div className="max-w-4xl mx-auto">
          {/* Introduction */}
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl mb-4 shadow-2xl"
              whileHover={{ scale: 1.1 }}
            >
              <Heart className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-white text-4xl mb-3">Mental Health Assessment</h1>
            <p className="text-cream-100 text-lg max-w-2xl mx-auto">
              Help us understand your current state better. These assessments will guide us in providing you with the best support.
            </p>
          </motion.div>

          {/* PHQ-9 Questionnaire */}
          <motion.div
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10 mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 rounded-2xl px-6 py-4 mb-6">
              <h2 className="text-white text-2xl text-center">Patient Health Questionnaire-9 (PHQ-9)</h2>
            </div>
            
            <p className="text-cream-100 mb-6">
              Over the <span className="text-white">last 2 weeks</span>, how often have you been bothered by any of the following problems?
            </p>

            <div className="space-y-6">
              {phq9Questions.map((question, index) => (
                <div key={index} className="border-b border-white/10 pb-6 last:border-0">
                  <p className="text-white mb-4">
                    <span className="text-teal-400 mr-2">{index + 1}.</span>
                    {question}
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {responseOptions.map((option) => (
                      <motion.button
                        key={option.label}
                        type="button"
                        onClick={() => handlePhq9Answer(index, responseOptions.indexOf(option))}
                        className={`px-6 py-4 rounded-2xl border-2 transition-all backdrop-blur-sm ${
                          phq9Answers[index] === responseOptions.indexOf(option)
                            ? 'bg-teal-400/35 border-white text-white shadow-sm ring-2 ring-white'
                            : 'bg-white/10 border-white text-white hover:bg-white/20 ring-1 ring-white/30'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="text-center text-white text-sm font-medium">{option.label}</div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              ))}

              {/* PHQ-9 Difficulty Question */}
              <div className="pt-6 border-t-2 border-white/20">
                <p className="text-white mb-4">
                  If you checked off <span className="text-teal-400">any</span> problems, how <span className="text-teal-400">difficult</span> have these problems made it for you to do your work, take care of things at home, or get along with other people?
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {difficultyOptions.map((option) => (
                    <motion.button
                      key={option}
                      type="button"
                      onClick={() => setPhq9Difficulty(option)}
                      className={`px-6 py-4 rounded-2xl border-2 transition-all backdrop-blur-sm ${
                          phq9Difficulty === option
                            ? 'bg-coral-400/35 border-white text-white shadow-sm ring-2 ring-white'
                            : 'bg-white/10 border-white text-white hover:bg-white/20 ring-1 ring-white/30'
                        }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="text-center text-white text-sm font-medium">{option}</div>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Visual Divider */}
          <motion.div 
            className="flex items-center justify-center my-12"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-cream-100/30 to-transparent"></div>
            <motion.div 
              className="mx-6 flex items-center gap-3 bg-slate-900/60 backdrop-blur-xl px-6 py-3 rounded-full border border-white/20"
              whileHover={{ scale: 1.05 }}
            >
              <CheckCircle className="w-5 h-5 text-teal-400" />
              <span className="text-cream-100">Next Assessment</span>
              <CheckCircle className="w-5 h-5 text-coral-400" />
            </motion.div>
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-cream-100/30 to-transparent"></div>
          </motion.div>

          {/* GAD-7 Questionnaire */}
          <motion.div
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10 mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="bg-gradient-to-r from-coral-500 to-coral-700 rounded-2xl px-6 py-4 mb-6">
              <h2 className="text-white text-2xl text-center">GAD-7 Anxiety</h2>
            </div>
            
            <p className="text-cream-100 mb-6">
              Over the <span className="text-white">last two weeks</span>, how often have you been bothered by the following problems?
            </p>

            <div className="space-y-6">
              {gad7Questions.map((question, index) => (
                <div key={index} className="border-b border-white/10 pb-6 last:border-100">
                  <p className="text-white mb-4">
                    <span className="text-coral-400 mr-2">{index + 1}.</span>
                    {question}
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {responseOptions.map((option) => (
                      <motion.button
                        key={option.label}
                        type="button"
                        onClick={() => handleGad7Answer(index, responseOptions.indexOf(option))}
                        className={`px-6 py-4 rounded-2xl border-2 transition-all backdrop-blur-sm ${
                          gad7Answers[index] === responseOptions.indexOf(option)
                            ? 'bg-coral-400/35 border-white text-white shadow-sm ring-2 ring-white'
                            : 'bg-white/10 border-white text-white hover:bg-white/20 ring-1 ring-white/30'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="text-center text-white text-sm font-medium">{option.label}</div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              ))}

              {/* GAD-7 Difficulty Question */}
              <div className="pt-6 border-t-2 border-white/20">
                <p className="text-white mb-4">
                  If you checked any problems, how <span className="text-coral-400">difficult</span> have they made it for you to do your work, take care of things at home, or get along with other people?
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {difficultyOptions.map((option) => (
                    <motion.button
                      key={option}
                      type="button"
                      onClick={() => setGad7Difficulty(option)}
                      className={`px-6 py-4 rounded-2xl border-2 transition-all backdrop-blur-sm ${
                        gad7Difficulty === option
                          ? 'bg-teal-400/35 border-white text-white shadow-sm ring-2 ring-white'
                          : 'bg-white/10 border-white text-white hover:bg-white/20 ring-1 ring-white/30'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="text-center text-white text-sm font-medium">{option}</div>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Submit Button */}
          <motion.div
            className="flex justify-center mt-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <motion.button
              onClick={handleSubmit}
              className="bg-gradient-to-r from-coral-400 to-coral-600 text-white px-12 py-5 rounded-2xl shadow-2xl hover:shadow-coral-500/50 transition-all flex items-center gap-3 group text-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Go to Dashboard
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </motion.button>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
