import { motion } from 'motion/react';
import { Brain, Heart, Search, Filter, Video, Music, BookOpen, FileText, Play, Download, Clock, Users, Eye, TrendingUp, Calendar, Bot, Headphones, Book, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';

export function ResourcesPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', label: 'All Resources', icon: BookOpen },
    { id: 'mindfulness', label: 'Mindfulness', icon: Heart },
    { id: 'anxiety', label: 'Anxiety Relief', icon: Sparkles },
    { id: 'depression', label: 'Depression Support', icon: Users },
    { id: 'stress', label: 'Stress Management', icon: Brain },
    { id: 'meditation', label: 'Meditation', icon: Headphones },
  ];

  const resources = [
    {
      id: 1,
      title: "5-Minute Breathing Exercise for Anxiety",
      type: "video",
      category: "anxiety",
      duration: "5:30",
      author: "Dr. Sarah Johnson",
      date: "Nov 28, 2025",
      views: "1.2K",
      thumbnail: "from-teal-400 to-teal-600",
      tags: ["Breathing", "Quick Relief"]
    },
    {
      id: 2,
      title: "Understanding Depression: A Comprehensive Guide",
      type: "article",
      category: "depression",
      duration: "15 min read",
      author: "Dr. Michael Chen",
      date: "Nov 27, 2025",
      views: "856",
      thumbnail: "from-coral-400 to-coral-600",
      tags: ["Guide", "Educational"]
    },
    {
      id: 3,
      title: "Guided Meditation for Sleep",
      type: "audio",
      category: "meditation",
      duration: "20:00",
      author: "Emily Davis",
      date: "Nov 26, 2025",
      views: "2.1K",
      thumbnail: "from-indigo-400 to-indigo-600",
      tags: ["Sleep", "Relaxation"]
    },
    {
      id: 4,
      title: "Mindfulness Techniques for Students",
      type: "video",
      category: "mindfulness",
      duration: "12:45",
      author: "Dr. Lisa Wang",
      date: "Nov 25, 2025",
      views: "945",
      thumbnail: "from-teal-400 to-teal-600",
      tags: ["Students", "Techniques"]
    },
    {
      id: 5,
      title: "Stress Relief Through Progressive Muscle Relaxation",
      type: "audio",
      category: "stress",
      duration: "18:30",
      author: "John Miller",
      date: "Nov 24, 2025",
      views: "1.5K",
      thumbnail: "from-coral-400 to-coral-600",
      tags: ["PMR", "Body Scan"]
    },
    {
      id: 6,
      title: "Cognitive Behavioral Therapy Basics",
      type: "article",
      category: "depression",
      duration: "10 min read",
      author: "Dr. Amanda Lee",
      date: "Nov 23, 2025",
      views: "678",
      thumbnail: "from-indigo-400 to-indigo-600",
      tags: ["CBT", "Therapy"]
    },
    {
      id: 7,
      title: "Morning Mindfulness Routine",
      type: "video",
      category: "mindfulness",
      duration: "8:15",
      author: "Sarah Johnson",
      date: "Nov 22, 2025",
      views: "1.8K",
      thumbnail: "from-teal-400 to-teal-600",
      tags: ["Morning", "Routine"]
    },
    {
      id: 8,
      title: "Overcoming Social Anxiety: Practical Steps",
      type: "article",
      category: "anxiety",
      duration: "12 min read",
      author: "Dr. Robert Taylor",
      date: "Nov 21, 2025",
      views: "1.1K",
      thumbnail: "from-coral-400 to-coral-600",
      tags: ["Social", "Practical"]
    },
  ];

  const stats = [
    { label: "Video Guides", value: "24", icon: Video, color: "from-teal-400 to-teal-600" },
    { label: "Audio Content", value: "18", icon: Music, color: "from-coral-400 to-coral-600" },
    { label: "Articles", value: "42", icon: FileText, color: "from-indigo-400 to-indigo-600" },
    { label: "Total Resources", value: "84", icon: BookOpen, color: "from-teal-400 to-coral-600" },
  ];

  const filteredResources = resources.filter(resource => {
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const getTypeIcon = (type: string) => {
    switch(type) {
      case 'video': return Video;
      case 'audio': return Music;
      case 'article': return FileText;
      default: return BookOpen;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-[#ED6962] relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div 
        className="absolute top-32 right-20 w-[500px] h-[500px] bg-teal-400/30 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, 50, 0],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div 
        className="absolute bottom-32 left-20 w-[600px] h-[600px] bg-coral-400/40 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          y: [0, -50, 0],
          opacity: [0.4, 0.6, 0.4],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Header */}
      <header className="relative z-10 px-8 py-6">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link to="/" className="flex items-center gap-3">
              <motion.div
                initial={{ opacity: 0, rotate: -180 }}
                animate={{ opacity: 1, rotate: 0 }}
                transition={{ duration: 0.8, type: "spring" }}
                className="flex items-center gap-3"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <span className="text-white text-2xl">MindMate</span>
              </motion.div>
            </Link>

            <motion.div 
              className="flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <nav className="flex items-center gap-2 bg-slate-900/40 backdrop-blur-xl rounded-2xl p-2 border border-white/10">
                <Link to="/dashboard">
                  <motion.button
                    className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <TrendingUp className="w-4 h-4" />
                    Dashboard
                  </motion.button>
                </Link>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Users className="w-4 h-4" />
                  Community
                </motion.button>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Calendar className="w-4 h-4" />
                  Book Session
                </motion.button>
                <motion.button
                  className="px-5 py-2.5 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <BookOpen className="w-4 h-4" />
                  Resources
                </motion.button>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Bot className="w-4 h-4" />
                  AI Chat
                </motion.button>
              </nav>
              <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center shadow-lg cursor-pointer border-2 border-white/20">
                <span className="text-white">JD</span>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-8 py-6">
        <div className="max-w-[1600px] mx-auto">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-10"
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-white text-5xl mb-3">Resource Library</h1>
                <p className="text-cream-100/80 text-lg">Explore therapeutic videos, guided meditations, and educational content</p>
              </div>
              <motion.button
                className="px-6 py-3 bg-gradient-to-r from-coral-400 to-coral-600 text-white rounded-2xl shadow-2xl hover:shadow-coral-500/50 flex items-center gap-2"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                <Download className="w-5 h-5" />
                Upload Resource
              </motion.button>
            </div>

            {/* Search and Filter Bar */}
            <div className="flex items-center gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-cream-100/50" />
                <input
                  type="text"
                  placeholder="Search resources, tags, or topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-14 pr-6 py-4 bg-slate-900/40 backdrop-blur-xl border border-white/20 rounded-2xl text-white placeholder-cream-100/50 focus:border-teal-400 focus:outline-none transition-all"
                />
              </div>
              <motion.button
                className="px-6 py-4 bg-slate-900/40 backdrop-blur-xl border border-white/20 rounded-2xl text-cream-100 hover:border-teal-400/50 transition-all flex items-center gap-2"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Filter className="w-5 h-5" />
                Filters
              </motion.button>
            </div>
          </motion.div>

          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-4 gap-5 mb-8"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="bg-slate-900/40 backdrop-blur-xl rounded-2xl p-6 border border-white/10 hover:border-white/30 transition-all"
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center shadow-lg`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-white text-3xl">{stat.value}</p>
                </div>
                <p className="text-cream-100/70">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>

          <div className="grid grid-cols-12 gap-6">
            {/* Sidebar - Categories */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="col-span-3"
            >
              <div className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-6 border border-white/10 shadow-2xl sticky top-6">
                <h3 className="text-white text-xl mb-4">Categories</h3>
                <div className="space-y-2">
                  {categories.map((category, index) => (
                    <motion.button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full px-4 py-3 rounded-xl text-left flex items-center gap-3 transition-all ${
                        selectedCategory === category.id
                          ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg'
                          : 'text-cream-100 hover:bg-white/10'
                      }`}
                      whileHover={{ x: 5 }}
                      whileTap={{ scale: 0.98 }}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.05 }}
                    >
                      <category.icon className="w-5 h-5" />
                      {category.label}
                    </motion.button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Main Content - Resources Grid */}
            <div className="col-span-9">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <div className="flex items-center justify-between mb-5">
                  <h3 className="text-white text-2xl">
                    {filteredResources.length} {selectedCategory === 'all' ? 'Resources' : categories.find(c => c.id === selectedCategory)?.label}
                  </h3>
                  <div className="flex items-center gap-2 text-cream-100/70 text-sm">
                    <span>Sort by:</span>
                    <select className="bg-slate-900/40 backdrop-blur-xl border border-white/20 rounded-xl px-4 py-2 text-white focus:border-teal-400 focus:outline-none">
                      <option>Most Recent</option>
                      <option>Most Popular</option>
                      <option>Duration</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  {filteredResources.map((resource, index) => {
                    const TypeIcon = getTypeIcon(resource.type);
                    return (
                      <motion.div
                        key={resource.id}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                        className="bg-slate-900/40 backdrop-blur-xl rounded-2xl border border-white/10 hover:border-teal-400/50 transition-all overflow-hidden group cursor-pointer"
                        whileHover={{ y: -5, scale: 1.02 }}
                      >
                        {/* Thumbnail */}
                        <div className={`h-48 bg-gradient-to-br ${resource.thumbnail} relative overflow-hidden`}>
                          <motion.div
                            className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
                            whileHover={{ backgroundColor: "rgba(0, 0, 0, 0.6)" }}
                          >
                            <motion.div
                              className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white/50"
                              whileHover={{ scale: 1.1 }}
                            >
                              <Play className="w-8 h-8 text-white ml-1" />
                            </motion.div>
                          </motion.div>
                          <div className="absolute top-4 left-4 flex items-center gap-2">
                            <div className="px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white text-xs flex items-center gap-1">
                              <TypeIcon className="w-3 h-3" />
                              {resource.type}
                            </div>
                            <div className="px-3 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white text-xs flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {resource.duration}
                            </div>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="p-5">
                          <h4 className="text-white text-lg mb-2 group-hover:text-teal-300 transition-colors">{resource.title}</h4>
                          <div className="flex items-center gap-3 text-cream-100/70 text-sm mb-3">
                            <span>{resource.author}</span>
                            <span>•</span>
                            <span>{resource.date}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 flex-wrap">
                              {resource.tags.map((tag, tagIndex) => (
                                <span key={tagIndex} className="px-3 py-1 bg-white/10 rounded-full text-cream-100 text-xs">
                                  {tag}
                                </span>
                              ))}
                            </div>
                            <div className="flex items-center gap-1 text-cream-100/70 text-sm">
                              <Eye className="w-4 h-4" />
                              {resource.views}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
