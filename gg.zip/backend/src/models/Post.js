import mongoose from "mongoose";

const commentSchema = new mongoose.Schema(
  {
    authorName: String,
    text: String,
    createdAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const postSchema = new mongoose.Schema(
  {
    author: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    authorName: String,
    title: String,
    content: String,
    tags: [String],
    likes: { type: Number, default: 0 },
    comments: [commentSchema],
  },
  { timestamps: true }
);

export const Post = mongoose.model("Post", postSchema);

