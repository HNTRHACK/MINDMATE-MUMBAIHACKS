import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import assessmentRoutes from "./routes/assessmentRoutes.js";
import sessionRoutes from "./routes/sessionRoutes.js";
import communityRoutes from "./routes/communityRoutes.js";

dotenv.config();

const app = express();

app.use(express.json());
app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true,
  })
);

app.get("/", (req, res) => {
  res.send("MindMate API is running");
});

app.use("/api/auth", authRoutes);
app.use("/api/assessments", assessmentRoutes);
app.use("/api/sessions", sessionRoutes);
app.use("/api/community", communityRoutes);

const PORT = process.env.PORT || 5000;

(async () => {
  console.log("🟡 Starting server...");
  await connectDB();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
})().catch((err) => {
  console.error("❌ Fatal startup error:", err);
  process.exit(1);
});

