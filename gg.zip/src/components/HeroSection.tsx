import { motion } from 'motion/react';
import { ArrowRight, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HeroSection() {
  return (
    <main className="relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-6">
      <div className="max-w-4xl mx-auto text-center">
        <motion.h1 
          className="text-white text-6xl md:text-7xl mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Your Mental Health Matters
        </motion.h1>
        
        <motion.p 
          className="text-cream-100 text-xl md:text-2xl mb-12 max-w-3xl mx-auto leading-relaxed"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          A comprehensive platform designed specifically for students to access mental health resources, connect with counsellors, and build supportive communities.
        </motion.p>

        {/* Creative button layout - aligned horizontally with offset */}
        <div className="flex items-center justify-center gap-6 flex-wrap">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ 
              duration: 0.8, 
              delay: 0.6,
              type: "spring",
              stiffness: 100
            }}
            whileHover={{ 
              scale: 1.05,
              rotate: -2,
            }}
            whileTap={{ scale: 0.95 }}
          >
            <Link to="/signup" className="block">
              <button className="bg-gradient-to-r from-coral-400 to-coral-500 text-white px-8 py-4 rounded-2xl shadow-2xl hover:shadow-coral-500/50 transition-all flex items-center gap-2 group">
                <Heart className="w-5 h-5 group-hover:scale-110 transition-transform" />
                Get Started Free
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ 
              duration: 0.8, 
              delay: 0.8,
              type: "spring",
              stiffness: 100
            }}
            whileHover={{ 
              scale: 1.05,
              rotate: 2,
            }}
            whileTap={{ scale: 0.95 }}
          >
            <Link to="/login" className="block">
              <button className="bg-cream-50/10 backdrop-blur-sm text-cream-50 px-8 py-4 rounded-2xl border-2 border-cream-50/30 hover:bg-cream-50/20 hover:border-cream-50/50 transition-all shadow-xl flex items-center gap-2 group">
                Sign In
                <motion.div
                  animate={{ x: [0, 3, 0] }}
                  transition={{ 
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <ArrowRight className="w-5 h-5" />
                </motion.div>
              </button>
            </Link>
          </motion.div>
        </div>

        {/* Floating elements */}
        <motion.div
          className="absolute left-1/4 top-20 w-3 h-3 bg-teal-400 rounded-full"
          animate={{
            y: [0, -20, 0],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute right-1/4 bottom-20 w-2 h-2 bg-coral-400 rounded-full"
          animate={{
            y: [0, 20, 0],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
        <motion.div
          className="absolute left-1/3 bottom-32 w-2 h-2 bg-cream-300 rounded-full"
          animate={{
            y: [0, -15, 0],
            x: [0, 10, 0],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
      </div>
    </main>
  );
}
