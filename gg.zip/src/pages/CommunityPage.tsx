// src/pages/CommunityPage.tsx
import { useState, useEffect, useRef, KeyboardEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Brain,
  Users,
  MessageCircle,
  Search,
  Plus,
  Calendar,
  BookOpen,
  Bot,
  TrendingUp,
  Send,
  Smile,
  Paperclip,
  MoreVertical,
} from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';

interface Message {
  id: number;
  user: string;
  text: string;
  time: string;
  isOwn: boolean;
}

export function CommunityPage() {
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'groups' | 'messages' | 'search'>('groups');
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [messages, setMessages] = useState<{ [key: string]: Message[] }>({
    'Anxiety Support': [
      {
        id: 1,
        user: 'Sarah M.',
        text: 'Hi everyone! Just joined this group. Looking forward to connecting with you all.',
        time: '10:30 AM',
        isOwn: false,
      },
      {
        id: 2,
        user: 'You',
        text: 'Welcome Sarah! This is a great supportive community.',
        time: '10:32 AM',
        isOwn: true,
      },
      {
        id: 3,
        user: 'Mike J.',
        text: 'Welcome! Feel free to share anything you\'re comfortable with.',
        time: '10:35 AM',
        isOwn: false,
      },
    ],
    'Student Wellness': [
      {
        id: 1,
        user: 'Emma K.',
        text: 'Does anyone have tips for managing exam stress?',
        time: '9:15 AM',
        isOwn: false,
      },
      {
        id: 2,
        user: 'You',
        text: 'I find meditation really helpful during stressful times!',
        time: '9:20 AM',
        isOwn: true,
      },
    ],
    'Mindfulness Circle': [
      {
        id: 1,
        user: 'Alex P.',
        text: 'Good morning everyone! Starting my day with 10 minutes of mindfulness.',
        time: '8:00 AM',
        isOwn: false,
      },
      {
        id: 2,
        user: 'Jordan L.',
        text: 'That\'s inspiring! I should do the same.',
        time: '8:15 AM',
        isOwn: false,
      },
      {
        id: 3,
        user: 'You',
        text: 'Great idea! I\'ll join you in this practice.',
        time: '8:20 AM',
        isOwn: true,
      },
    ],
  });

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const userGroups = [
    { name: 'Anxiety Support', members: 124, active: '32 online', color: 'from-teal-400 to-teal-600', description: 'General support for anxiety and worry.' },
    { name: 'Student Wellness', members: 89, active: '18 online', color: 'from-coral-400 to-coral-600', description: 'Mental health space for students.' },
    { name: 'Mindfulness Circle', members: 156, active: '45 online', color: 'from-indigo-400 to-indigo-600', description: 'Daily mindfulness and grounding.' },
  ];

  // Pre-select group from URL ?group=Anxiety%20Support
  useEffect(() => {
    const groupParam = searchParams.get('group');
    if (groupParam) setSelectedGroup(groupParam);
  }, [searchParams]);

  // Auto-scroll when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedGroup]);

  const handleSendMessage = () => {
    if (!selectedGroup || !messageText.trim()) return;

    const newMessage: Message = {
      id: Date.now(),
      user: 'You',
      text: messageText.trim(),
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      isOwn: true,
    };

    setMessages((prev) => ({
      ...prev,
      [selectedGroup]: [...(prev[selectedGroup] || []), newMessage],
    }));

    setMessageText('');
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const selectedGroupData = userGroups.find((g) => g.name === selectedGroup);

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-coral-600 relative">
      {/* Background blobs */}
      <motion.div
        className="absolute top-32 right-20 w-[500px] h-[500px] bg-teal-400/30 rounded-full blur-3xl"
        animate={{ scale: [1, 1.3, 1], x: [0, 50, 0], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-32 left-20 w-[600px] h-[600px] bg-coral-400/40 rounded-full blur-3xl"
        animate={{ scale: [1.2, 1, 1.2], y: [0, -50, 0], opacity: [0.4, 0.6, 0.4] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-indigo-400/20 rounded-full blur-3xl"
        animate={{ scale: [1, 1.4, 1], rotate: [0, 180, 360], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Header */}
      <header className="relative z-10 px-4 sm:px-8 py-4 sm:py-6 flex-shrink-0">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <Link to="/" className="flex items-center gap-3">
              <motion.div
                initial={{ opacity: 0, rotate: -180 }}
                animate={{ opacity: 1, rotate: 0 }}
                transition={{ duration: 0.8, type: 'spring' }}
                className="flex items-center gap-3"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Brain className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                </div>
                <span className="text-white text-xl sm:text-2xl">MindMate</span>
              </motion.div>
            </Link>

            <motion.div
              className="flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <nav className="flex items-center gap-2 bg-slate-900/40 backdrop-blur-xl rounded-2xl p-1.5 sm:p-2 border border-white/10 text-sm">
                <Link to="/dashboard">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span className="hidden sm:inline">Dashboard</span>
                  </motion.button>
                </Link>

                <motion.button
                  className="px-3 sm:px-5 py-2 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Users className="w-4 h-4" />
                  <span className="hidden sm:inline">Community</span>
                </motion.button>

                <Link to="/book-session">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Calendar className="w-4 h-4" />
                    <span className="hidden sm:inline">Book Session</span>
                  </motion.button>
                </Link>

                <Link to="/resources">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <BookOpen className="w-4 h-4" />
                    <span className="hidden sm:inline">Resources</span>
                  </motion.button>
                </Link>

                <Link to="/chat">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Bot className="w-4 h-4" />
                    <span className="hidden sm:inline">AI Chat</span>
                  </motion.button>
                </Link>
              </nav>

              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center shadow-lg cursor-pointer border-2 border-white/20 text-xs sm:text-sm">
                <span className="text-white">JD</span>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main Community Hub */}
      <main className="relative z-10 px-4 sm:px-8 pb-8">
        <div className="max-w-[1600px] mx-auto">
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-4 sm:mb-6 pt-2 sm:pt-6"
          >
            <h1 className="text-white text-3xl sm:text-4xl mb-2">Community Hub</h1>
            <p className="text-cream-100/80 text-base sm:text-lg">
              Connect with peers, join support groups, and build meaningful relationships.
            </p>
          </motion.div>

          {/* Main container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/10 overflow-hidden"
            style={{ minHeight: '500px', height: 'calc(100vh - 220px)' }}
          >
            <div className="flex flex-col md:flex-row h-full">
              {/* Sidebar */}
              <motion.div
                initial={{ x: -30, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="w-full md:w-80 bg-slate-900/60 backdrop-blur-xl border-b md:border-b-0 md:border-r border-white/10 flex flex-col"
              >
                {/* Tabs */}
                <div className="p-3 sm:p-4 border-b border-white/10">
                  <div className="flex gap-1 bg-slate-900/40 rounded-xl p-1">
                    <motion.button
                      onClick={() => setActiveTab('groups')}
                      className={`flex-1 px-2 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 text-xs ${
                        activeTab === 'groups'
                          ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white'
                          : 'text-cream-100/70 hover:text-white hover:bg-white/10'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Users className="w-4 h-4" />
                      <span className="hidden sm:inline">Groups</span>
                    </motion.button>

                    <motion.button
                      onClick={() => setActiveTab('messages')}
                      className={`flex-1 px-2 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 text-xs ${
                        activeTab === 'messages'
                          ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white'
                          : 'text-cream-100/70 hover:text-white hover:bg-white/10'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="hidden sm:inline">Messages</span>
                    </motion.button>

                    <motion.button
                      onClick={() => setActiveTab('search')}
                      className={`flex-1 px-2 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 text-xs ${
                        activeTab === 'search'
                          ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white'
                          : 'text-cream-100/70 hover:text-white hover:bg-white/10'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Search className="w-4 h-4" />
                      <span className="hidden sm:inline">Search</span>
                    </motion.button>
                  </div>
                </div>

                {/* Sidebar content */}
                <div className="flex-1 overflow-hidden flex flex-col">
                  <AnimatePresence mode="wait">
                    {activeTab === 'groups' && (
                      <motion.div
                        key="groups"
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -15 }}
                        transition={{ duration: 0.25 }}
                        className="flex-1 flex flex-col"
                      >
                        <div className="p-4 flex items-center justify-between border-b border-white/10">
                          <h3 className="text-white text-sm">Support Groups</h3>
                          <motion.button
                            className="px-3 py-1.5 bg-gradient-to-r from-coral-400 to-coral-600 text-white rounded-lg flex items-center gap-2 text-xs"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            <Plus className="w-3 h-3" />
                            Create
                          </motion.button>
                        </div>

                        <div className="flex-1 overflow-y-auto p-3 space-y-3">
                          {userGroups.map((group, index) => (
                            <motion.div
                              key={group.name}
                              initial={{ opacity: 0, x: -15 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.25 + index * 0.05 }}
                              onClick={() => setSelectedGroup(group.name)}
                              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                                selectedGroup === group.name
                                  ? 'bg-gradient-to-r from-teal-400/25 to-teal-600/25 border-teal-400/50'
                                  : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                              }`}
                              whileHover={{ scale: 1.02 }}
                            >
                              <div className="flex items-start gap-3">
                                <div
                                  className={`w-11 h-11 bg-gradient-to-br ${group.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg`}
                                >
                                  <Users className="w-6 h-6 text-white" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-white text-sm mb-0.5 truncate">{group.name}</p>
                                  <p className="text-cream-100/70 text-xs">{group.description}</p>
                                  <p className="text-cream-100/60 text-[11px] mt-1">{group.members} members</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-white/10">
                                <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
                                <p className="text-teal-300 text-[11px]">{group.active}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {activeTab === 'messages' && (
                      <motion.div
                        key="messages"
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -15 }}
                        transition={{ duration: 0.25 }}
                        className="flex-1 flex items-center justify-center p-8"
                      >
                        <div className="text-center max-w-xs mx-auto">
                          <div className="w-14 h-14 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                            <MessageCircle className="w-7 h-7 text-white" />
                          </div>
                          <p className="text-cream-100/80 text-sm">No direct messages yet</p>
                          <p className="text-cream-100/50 text-xs mt-2">
                            Start a conversation by connecting in your groups first.
                          </p>
                        </div>
                      </motion.div>
                    )}

                    {activeTab === 'search' && (
                      <motion.div
                        key="search"
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -15 }}
                        transition={{ duration: 0.25 }}
                        className="flex-1 p-4 flex flex-col gap-4"
                      >
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream-100/50" />
                          <input
                            type="text"
                            placeholder="Search groups or people..."
                            className="w-full pl-10 pr-4 py-2.5 bg-white/10 border border-white/20 rounded-xl text-sm text-white placeholder:text-cream-100/50 focus:outline-none focus:border-teal-400/60 transition-all"
                          />
                        </div>
                        <div className="flex-1 flex items-center justify-center">
                          <div className="text-center max-w-xs mx-auto">
                            <div className="w-14 h-14 bg-gradient-to-br from-indigo-400 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                              <Search className="w-7 h-7 text-white" />
                            </div>
                            <p className="text-cream-100/80 text-sm">Search for groups</p>
                            <p className="text-cream-100/50 text-xs mt-2">
                              Find communities that match your interests and challenges.
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>

              {/* Chat Area */}
              <motion.div
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.45, delay: 0.3 }}
                className="flex-1 bg-slate-900/20 backdrop-blur-sm flex flex-col"
              >
                {selectedGroup ? (
                  <>
                    {/* Chat header */}
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className="p-4 sm:p-6 border-b border-white/10 bg-slate-900/40 backdrop-blur-xl"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 sm:gap-4">
                          <div
                            className={`w-11 h-11 sm:w-14 sm:h-14 bg-gradient-to-br ${
                              selectedGroupData?.color ?? 'from-teal-400 to-teal-600'
                            } rounded-xl flex items-center justify-center shadow-lg`}
                          >
                            <Users className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                          </div>
                          <div>
                            <h2 className="text-white text-base sm:text-xl">{selectedGroup}</h2>
                            <div className="flex items-center gap-2 mt-1">
                              <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
                              <p className="text-teal-300 text-xs sm:text-sm">
                                {selectedGroupData?.active ?? 'Online'}
                              </p>
                            </div>
                          </div>
                        </div>
                        <motion.button
                          className="w-9 h-9 sm:w-10 sm:h-10 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5 text-cream-100" />
                        </motion.button>
                      </div>
                    </motion.div>

                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-3 sm:space-y-4">
                      <AnimatePresence>
                        {(messages[selectedGroup] || []).map((message, index) => (
                          <motion.div
                            key={message.id}
                            initial={{ opacity: 0, y: 15 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -15 }}
                            transition={{ duration: 0.25, delay: index * 0.03 }}
                            className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className={`max-w-[75%] sm:max-w-md ${message.isOwn ? 'order-2' : 'order-1'}`}>
                              {!message.isOwn && (
                                <p className="text-teal-300 text-xs sm:text-sm mb-1 ml-1">{message.user}</p>
                              )}
                              <div
                                className={`px-3 sm:px-5 py-2 sm:py-3 rounded-2xl text-sm sm:text-base ${
                                  message.isOwn
                                    ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white'
                                    : 'bg-white/10 text-cream-100 border border-white/20'
                                }`}
                              >
                                <p>{message.text}</p>
                              </div>
                              <p
                                className={`text-cream-100/50 text-[10px] sm:text-xs mt-1 ${
                                  message.isOwn ? 'text-right mr-1' : 'ml-1'
                                }`}
                              >
                                {message.time}
                              </p>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                      <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 }}
                      className="p-3 sm:p-6 border-t border-white/10 bg-slate-900/40 backdrop-blur-xl"
                    >
                      <div className="flex items-end gap-2 sm:gap-3">
                        <motion.button
                          className="w-9 h-9 sm:w-10 sm:h-10 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all flex-shrink-0"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Paperclip className="w-4 h-4 sm:w-5 sm:h-5 text-cream-100" />
                        </motion.button>

                        <div className="flex-1 relative">
                          <textarea
                            value={messageText}
                            onChange={(e) => setMessageText(e.target.value)}
                            onKeyDown={handleKeyPress}
                            placeholder="Type your message..."
                            className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-white/10 border border-white/20 rounded-xl text-sm sm:text-base text-white placeholder:text-cream-100/50 focus:outline-none focus:border-teal-400/60 transition-all resize-none"
                            rows={1}
                            style={{ minHeight: 40, maxHeight: 120 }}
                          />
                        </div>

                        <motion.button
                          className="w-9 h-9 sm:w-10 sm:h-10 bg-white/10 hover:bg-white/20 rounded-xl flex items-center justify-center transition-all flex-shrink-0"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Smile className="w-4 h-4 sm:w-5 sm:h-5 text-cream-100" />
                        </motion.button>

                        <motion.button
                          onClick={handleSendMessage}
                          disabled={!messageText.trim()}
                          className="w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-r from-teal-400 to-teal-600 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed rounded-xl flex items-center justify-center transition-all flex-shrink-0"
                          whileHover={{ scale: messageText.trim() ? 1.05 : 1 }}
                          whileTap={{ scale: messageText.trim() ? 0.95 : 1 }}
                        >
                          <Send className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                        </motion.button>
                      </div>
                    </motion.div>
                  </>
                ) : (
                  <div className="flex-1 flex items-center justify-center">
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.3 }}
                      className="text-center px-4"
                    >
                      <motion.div
                        animate={{ rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                        className="inline-block mb-6"
                      >
                        <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-teal-400 to-teal-600 rounded-3xl flex items-center justify-center shadow-2xl">
                          <MessageCircle className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
                        </div>
                      </motion.div>
                      <h2 className="text-white text-2xl sm:text-3xl mb-2">Select a Conversation</h2>
                      <p className="text-cream-100/70 text-sm sm:text-lg">
                        Choose a group in the left panel to start chatting.
                      </p>
                    </motion.div>
                  </div>
                )}
              </motion.div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
