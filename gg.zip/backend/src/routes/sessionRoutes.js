import express from "express";
import { authRequired } from "../middleware/authMiddleware.js";
import { Session } from "../models/Session.js";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

function generateFakeMeetLink() {
  const short = uuidv4().split("-")[0];
  return `https://meet.google.com/${short}`;
}

// POST /api/sessions
// Book a new session
router.post("/", authRequired, async (req, res) => {
  try {
    const { counselorName, specialty, date, time, durationMinutes } = req.body;

    if (!counselorName || !date || !time) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const meetLink = generateFakeMeetLink();

    const session = await Session.create({
      user: req.user._id,
      counselorName,
      specialty,
      date,
      time,
      durationMinutes: durationMinutes || 45,
      meetLink,
    });

    res.status(201).json({
      message: "Session booked",
      session,
    });
  } catch (err) {
    console.error("Session error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// GET /api/sessions/my
// Get all sessions for current logged-in user
router.get("/my", authRequired, async (req, res) => {
  try {
    const sessions = await Session.find({ user: req.user._id }).sort({
      createdAt: -1,
    });
    res.json(sessions);
  } catch (err) {
    console.error("Get sessions error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
