import { motion } from 'motion/react';
import { Brain, Heart, ArrowRight, User, Mail, Lock, FileText } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';

export function SignUpPage() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState('student');
  const [formData, setFormData] = useState({
    fullName: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    bio: ''
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: formData.fullName,
          username: formData.username,
          email: formData.email,
          password: formData.password,
          bio: formData.bio,
          userType,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message || "Signup failed");
        return;
      }

      // Save JWT + User in localStorage
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      navigate("/assessment");
    } catch (err) {
      console.error(err);
      alert("Something went wrong. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-[#ED6962] relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div 
        className="absolute top-20 left-10 w-96 h-96 bg-teal-400/40 rounded-full blur-3xl"
        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.7, 0.5] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute bottom-20 right-10 w-96 h-96 bg-coral-400/50 rounded-full blur-3xl"
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.6, 0.4, 0.6] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cream-100/20 rounded-full blur-3xl"
        animate={{ scale: [1, 1.1, 1], rotate: [0, 180, 360] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      />

      {/* Header */}
      <header className="relative z-10 px-6 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-coral-400 to-coral-600 rounded-xl flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-white text-xl">MindMate</span>
            </motion.div>
          </Link>

          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link to="/login">
              <button className="text-cream-100 hover:text-white transition-colors px-4 py-2 rounded-lg hover:bg-white/10">
                Login
              </button>
            </Link>
            <Link to="/signup">
              <button className="bg-cream-50 text-slate-900 px-5 py-2 rounded-lg hover:bg-cream-100 transition-all hover:shadow-lg">
                Sign Up
              </button>
            </Link>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-6 py-8">
        <div className="max-w-lg w-full">
          {/* Welcome Section */}
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl mb-4 shadow-2xl"
              whileHover={{ scale: 1.1, rotate: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Heart className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-white text-4xl mb-2">Join MindMate</h1>
            <p className="text-cream-100">Create your account to start your mental health journey</p>
          </motion.div>

          {/* Sign Up Form */}
          <motion.div
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-white text-2xl mb-2">Create Account</h2>
            <p className="text-cream-100/80 mb-6">Fill in your information to get started</p>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* User Type Selection */}
              <div>
                <label className="text-cream-100 block mb-3">I am a</label>
                <div className="flex gap-4">
                  <motion.button
                    type="button"
                    onClick={() => setUserType('student')}
                    className={`flex-1 px-4 py-3 rounded-xl border-2 transition-all flex items-center gap-2 justify-center ${
                      userType === 'student'
                        ? 'bg-teal-400/20 border-teal-400 text-white'
                        : 'bg-white/5 border-white/20 text-cream-100'
                    }`}
                  >
                    <User className="w-4 h-4" /> Student
                  </motion.button>

                  <motion.button
                    type="button"
                    onClick={() => setUserType('counselor')}
                    className={`flex-1 px-4 py-3 rounded-xl border-2 transition-all flex items-center gap-2 justify-center ${
                      userType === 'counselor'
                        ? 'bg-coral-400/20 border-coral-400 text-white'
                        : 'bg-white/5 border-white/20 text-cream-100'
                    }`}
                  >
                    <Heart className="w-4 h-4" /> Counselor
                  </motion.button>
                </div>
              </div>

              {/* Full Name + Username */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-cream-100 block mb-2">Full Name</label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white"
                  />
                </div>

                <div>
                  <label className="text-cream-100 block mb-2">Username</label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({...formData, username: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="text-cream-100 block mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white"
                />
              </div>

              {/* Password + Confirm */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-cream-100 block mb-2">Password</label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white"
                  />
                </div>

                <div>
                  <label className="text-cream-100 block mb-2">Confirm</label>
                  <input
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white"
                  />
                </div>
              </div>

              {/* Bio */}
              <div>
                <label className="text-cream-100 block mb-2">Bio (Optional)</label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) => setFormData({...formData, bio: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white resize-none"
                />
              </div>

              {/* Buttons */}
              <div className="flex gap-4 pt-2">
                <motion.button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-coral-400 to-coral-600 text-white py-4 rounded-xl shadow-lg"
                >
                  Create Account
                  <ArrowRight className="w-5 h-5 inline-block ml-2" />
                </motion.button>

                <Link to="/login" className="flex-1">
                  <motion.button
                    type="button"
                    className="w-full bg-white/5 backdrop-blur-sm text-cream-100 py-4 rounded-xl border-2 border-white/20"
                  >
                    Sign In Instead
                  </motion.button>
                </Link>
              </div>
            </form>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
