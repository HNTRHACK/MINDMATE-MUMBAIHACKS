import express from "express";
import { authRequired } from "../middleware/authMiddleware.js";
import { Assessment } from "../models/Assessment.js";

const router = express.Router();

// POST /api/assessments
router.post("/", authRequired, async (req, res) => {
  try {
    const { phq9Answers = [], gad7Answers = [] } = req.body;

    const phq9Score = phq9Answers.reduce(
      (sum, v) => sum + (typeof v === "number" && v >= 0 ? v : 0),
      0
    );
    const gad7Score = gad7Answers.reduce(
      (sum, v) => sum + (typeof v === "number" && v >= 0 ? v : 0),
      0
    );

    const assessment = await Assessment.create({
      user: req.user._id,
      phq9Answers,
      gad7Answers,
      phq9Score,
      gad7Score,
    });

    res.status(201).json({
      message: "Assessment saved",
      assessment,
    });
  } catch (err) {
    console.error("Assessment error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
