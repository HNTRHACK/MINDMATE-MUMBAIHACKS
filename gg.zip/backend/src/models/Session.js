import mongoose from "mongoose";

const sessionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    counselorName: { type: String, required: true },
    specialty: { type: String },
    date: { type: String, required: true },   // e.g. "2025-11-30"
    time: { type: String, required: true },   // e.g. "14:00"
    durationMinutes: { type: Number, default: 45 },
    meetLink: { type: String, required: true },
    status: {
      type: String,
      enum: ["upcoming", "completed", "cancelled"],
      default: "upcoming",
    },
  },
  { timestamps: true }
);

export const Session = mongoose.model("Session", sessionSchema);
