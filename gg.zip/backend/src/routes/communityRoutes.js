import express from "express";
import { authRequired } from "../middleware/authMiddleware.js";
import { Post } from "../models/Post.js";

const router = express.Router();

// GET /api/community
router.get("/", async (req, res) => {
  try {
    const posts = await Post.find().sort({ createdAt: -1 }).limit(50);
    res.json(posts);
  } catch (err) {
    console.error("Get posts error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// POST /api/community
router.post("/", authRequired, async (req, res) => {
  try {
    const { title, content, tags = [] } = req.body;

    const post = await Post.create({
      author: req.user._id,
      authorName: req.user.fullName,
      title,
      content,
      tags,
    });

    res.status(201).json({ message: "Post created", post });
  } catch (err) {
    console.error("Create post error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
