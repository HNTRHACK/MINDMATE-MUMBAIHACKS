// src/pages/BookSessionPage.tsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Brain,
  Calendar,
  Users,
  BookOpen,
  Bot,
  TrendingUp,
  Star,
  User,
  Clock,
  Video,
  ChevronLeft,
  ChevronRight,
  MapPin,
  X,
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Counsellor {
  id: number;
  name: string;
  rating: number;
  reviews: number;
  specialties: string[];
  available: boolean;
  availability: string;
  avatar: string;
}

interface Booking {
  id: number;
  sessionName: string;
  description: string;
  counsellor: string;
  date: string;
  time: string;
  type: 'online' | 'offline';
  price: number;
  meetLink?: string;
}

// fallback meet link generator if backend doesn't give one
const generateMeetLink = () => {
  const part = () => Math.random().toString(36).substring(2, 6);
  return `https://meet.google.com/${part()}-${part()}-${part()}`;
};

export function BookSessionPage() {
  const [activeTab, setActiveTab] = useState<'book' | 'bookings'>('book');
  const [selectedCounsellor, setSelectedCounsellor] = useState<Counsellor | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<'online' | 'offline' | null>(null);
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [showBookingDialog, setShowBookingDialog] = useState(false);
  const [sessionName, setSessionName] = useState('');
  const [sessionDescription, setSessionDescription] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);

  const counsellors: Counsellor[] = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      rating: 4.8,
      reviews: 24,
      specialties: ['Depression', 'Anxiety', 'Stress'],
      available: true,
      availability: 'Available today',
      avatar: 'SJ',
    },
    {
      id: 2,
      name: 'David Martinez',
      rating: 4.9,
      reviews: 32,
      specialties: ['Depression', 'Paranoia', 'Trauma'],
      available: true,
      availability: 'Available today',
      avatar: 'DM',
    },
    {
      id: 3,
      name: 'Dr. Emily Chen',
      rating: 4.8,
      reviews: 18,
      specialties: ['Anxiety', 'Relationships', 'Self-esteem'],
      available: true,
      availability: 'Available today',
      avatar: 'EC',
    },
    {
      id: 4,
      name: 'Michael Brown',
      rating: 4.7,
      reviews: 28,
      specialties: ['Stress', 'Work-life balance', 'Burnout'],
      available: false,
      availability: 'Available tomorrow',
      avatar: 'MB',
    },
  ];

  const timeSlots = [
    '09:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '01:00 PM',
    '02:00 PM',
    '03:00 PM',
    '04:00 PM',
    '05:00 PM',
    '06:00 PM',
    '07:00 PM',
  ];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    return { daysInMonth, startingDayOfWeek };
  };

  const isDatePast = (day: number) => {
    const today = new Date();
    const checkDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    today.setHours(0, 0, 0, 0);
    checkDate.setHours(0, 0, 0, 0);
    return checkDate < today;
  };

  const isSameDate = (date1: Date | null, day: number) => {
    if (!date1) return false;
    return (
      date1.getDate() === day &&
      date1.getMonth() === currentMonth.getMonth() &&
      date1.getFullYear() === currentMonth.getFullYear()
    );
  };

  const handleDateSelect = (day: number) => {
    if (isDatePast(day)) return;
    const newDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    setSelectedDate(newDate);
    setSelectedTime(null);
    setSelectedType(null);
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const handleBookSession = () => {
    if (!selectedCounsellor || !selectedDate || !selectedTime || !selectedType) {
      alert('Please select counsellor, date, time and session type.');
      return;
    }
    setShowBookingDialog(true);
  };

  const handleConfirmBooking = async () => {
    if (!selectedCounsellor || !selectedDate || !selectedTime || !selectedType || !sessionName) return;

    const formattedDate = selectedDate.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

    const price = selectedType === 'online' ? 6500 : 8000;

    let meetLink: string | undefined = undefined;

    try {
      const token = localStorage.getItem('token');

      if (!token) {
        alert('You are not logged in. Please login to sync bookings with backend.');
      } else {
        const res = await fetch('http://localhost:5000/api/sessions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            counselorName: selectedCounsellor.name,
            specialty: selectedCounsellor.specialties.join(', '),
            date: formattedDate,
            time: selectedTime,
            durationMinutes: 45,
            type: selectedType,
          }),
        });

        const data = await res.json();

        if (!res.ok) {
          console.error('Session create error:', data);
          alert(data.message || 'Failed to save booking to server. It will still appear locally.');
        } else if (data.session && data.session.meetLink) {
          meetLink = data.session.meetLink;
        }
      }
    } catch (error) {
      console.error('Error calling /api/sessions:', error);
      alert('Could not reach server. Booking will still appear locally.');
    }

    // If backend did not give us a meet link for online, generate one
    if (selectedType === 'online' && !meetLink) {
      meetLink = generateMeetLink();
    }

    const newBooking: Booking = {
      id: Date.now(),
      sessionName,
      description: sessionDescription,
      counsellor: selectedCounsellor.name,
      date: formattedDate,
      time: selectedTime,
      type: selectedType,
      price,
      meetLink,
    };

    setBookings((prev) => [...prev, newBooking]);
    setShowBookingDialog(false);
    setActiveTab('bookings');

    const userStr = localStorage.getItem('user');
    let userEmail = 'your registered email';
    try {
      if (userStr) {
        const user = JSON.parse(userStr);
        if (user?.email) userEmail = user.email;
      }
    } catch {
      // ignore
    }

    if (selectedType === 'offline') {
      alert(
        `Offline session booked!\n\nAn email has been sent to ${userEmail} with clinic location (demo).\n\nCounsellor: ${selectedCounsellor.name}\nDate: ${formattedDate}\nTime: ${selectedTime}\nLocation: MindMate Centre, Mumbai`
      );
    }

    if (selectedType === 'online') {
      alert(
        `Online session booked!\n\nGoogle Meet link: ${meetLink}\n\n(You can also join from "My Bookings".)`
      );
    }

    // reset
    setSessionName('');
    setSessionDescription('');
    setSelectedCounsellor(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setSelectedType(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-coral-600 relative">
      {/* Blobs */}
      <motion.div
        className="absolute top-32 right-20 w-[500px] h-[500px] bg-teal-400/30 rounded-full blur-3xl"
        animate={{ scale: [1, 1.3, 1], x: [0, 50, 0], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-32 left-20 w-[600px] h-[600px] bg-coral-400/40 rounded-full blur-3xl"
        animate={{ scale: [1.2, 1, 1.2], y: [0, -50, 0], opacity: [0.4, 0.6, 0.4] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Header */}
      <header className="relative z-10 px-4 sm:px-8 py-4 sm:py-6 flex-shrink-0">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <Link to="/" className="flex items-center gap-3">
              <motion.div
                initial={{ opacity: 0, rotate: -180 }}
                animate={{ opacity: 1, rotate: 0 }}
                transition={{ duration: 0.8, type: 'spring' }}
                className="flex items-center gap-3"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Brain className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                </div>
                <span className="text-white text-xl sm:text-2xl">MindMate</span>
              </motion.div>
            </Link>

            <motion.div
              className="flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <nav className="flex items-center gap-2 bg-slate-900/40 backdrop-blur-xl rounded-2xl p-1.5 sm:p-2 border border-white/10 text-sm">
                <Link to="/dashboard">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span className="hidden sm:inline">Dashboard</span>
                  </motion.button>
                </Link>

                <Link to="/community">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Users className="w-4 h-4" />
                    <span className="hidden sm:inline">Community</span>
                  </motion.button>
                </Link>

                <motion.button
                  className="px-3 sm:px-5 py-2 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Calendar className="w-4 h-4" />
                  <span className="hidden sm:inline">Book Session</span>
                </motion.button>

                <Link to="/resources">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <BookOpen className="w-4 h-4" />
                    <span className="hidden sm:inline">Resources</span>
                  </motion.button>
                </Link>

                <Link to="/chat">
                  <motion.button
                    className="px-3 sm:px-5 py-2 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Bot className="w-4 h-4" />
                    <span className="hidden sm:inline">AI Chat</span>
                  </motion.button>
                </Link>
              </nav>

              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center shadow-lg cursor-pointer border-2 border-white/20 text-xs sm:text-sm">
                <span className="text-white">JD</span>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="relative z-10 px-4 sm:px-8 pb-10">
        <div className="max-w-[1600px] mx-auto">
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 sm:mb-8"
          >
            <h1 className="text-white text-3xl sm:text-5xl mb-2 sm:mb-3">Counselling Sessions</h1>
            <p className="text-cream-100/80 text-base sm:text-xl">
              Book sessions with qualified mental health professionals.
            </p>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mb-6 sm:mb-8"
          >
            <div className="inline-flex flex-wrap gap-2 bg-slate-900/40 backdrop-blur-xl rounded-2xl p-1.5 sm:p-2 border border-white/10 text-sm">
              <motion.button
                onClick={() => setActiveTab('book')}
                className={`px-4 sm:px-6 py-2 sm:py-3 rounded-xl transition-all ${
                  activeTab === 'book'
                    ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg'
                    : 'text-cream-100/70 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Book Session
              </motion.button>
              <motion.button
                onClick={() => setActiveTab('bookings')}
                className={`px-4 sm:px-6 py-2 sm:py-3 rounded-xl transition-all ${
                  activeTab === 'bookings'
                    ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg'
                    : 'text-cream-100/70 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                My Bookings {bookings.length > 0 && <span className="ml-1.5 opacity-70">({bookings.length})</span>}
              </motion.button>
            </div>
          </motion.div>

          {/* Content */}
          {activeTab === 'book' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
              {/* Counsellors list */}
              <div className="lg:col-span-2">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <h2 className="text-white text-2xl sm:text-3xl mb-4 sm:mb-6">Available Counsellors</h2>
                  <div className="space-y-4">
                    {counsellors.map((c, index) => (
                      <motion.div
                        key={c.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 0.25 + index * 0.08 }}
                        onClick={() => {
                          setSelectedCounsellor(c);
                          setSelectedDate(null);
                          setSelectedTime(null);
                          setSelectedType(null);
                        }}
                        className={`bg-slate-900/60 backdrop-blur-xl rounded-2xl p-5 sm:p-6 border transition-all cursor-pointer ${
                          selectedCounsellor?.id === c.id
                            ? 'border-teal-400/50 shadow-xl shadow-teal-400/20'
                            : 'border-white/10 hover:border-white/30 hover:shadow-lg'
                        }`}
                        whileHover={{ scale: 1.01, y: -2 }}
                      >
                        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6">
                          <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
                            <span className="text-white text-lg sm:text-xl">{c.avatar}</span>
                          </div>

                          <div className="flex-1 min-w-0 w-full">
                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-2">
                              <div>
                                <h3 className="text-white text-lg sm:text-xl mb-1">{c.name}</h3>
                                <div className="flex items-center gap-2 text-sm">
                                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                                  <span className="text-cream-100/90">
                                    {c.rating}{' '}
                                    <span className="text-cream-100/60">({c.reviews} reviews)</span>
                                  </span>
                                </div>
                              </div>
                              <motion.button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedCounsellor(c);
                                  setSelectedDate(null);
                                  setSelectedTime(null);
                                  setSelectedType(null);
                                }}
                                className={`px-4 sm:px-6 py-1.5 sm:py-2 rounded-xl text-sm sm:text-base transition-all ${
                                  c.available
                                    ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white hover:shadow-lg'
                                    : 'bg-slate-700/50 text-cream-100/50 cursor-not-allowed'
                                }`}
                                whileHover={c.available ? { scale: 1.05 } : {}}
                                whileTap={c.available ? { scale: 0.95 } : {}}
                              >
                                {c.available ? 'Online' : 'Offline'}
                              </motion.button>
                            </div>

                            <div className="flex items-center gap-2 text-sm mb-3">
                              <Clock className="w-4 h-4 text-teal-400" />
                              <p className="text-cream-100/80">{c.availability}</p>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              {c.specialties.map((s) => (
                                <span
                                  key={s}
                                  className="px-3 py-1.5 bg-white/10 border border-white/20 rounded-lg text-cream-100/90 text-xs sm:text-sm"
                                >
                                  {s}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </div>

              {/* Booking sidebar */}
              <div className="lg:col-span-1">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="bg-slate-900/60 backdrop-blur-xl rounded-2xl p-6 sm:p-8 border border-white/10 lg:sticky lg:top-8"
                >
                  <h2 className="text-white text-xl sm:text-2xl mb-1">Book Your Session</h2>
                  <p className="text-cream-100/70 mb-6 sm:mb-8 text-sm sm:text-base">
                    Select a counsellor, date, time and type.
                  </p>

                  {selectedCounsellor ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-6 max-h-[70vh] overflow-y-auto pr-1"
                    >
                      {/* Selected counsellor */}
                      <div className="p-4 bg-white/10 rounded-xl border border-white/20">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 bg-gradient-to-br from-coral-400 to-coral-600 rounded-xl flex items-center justify-center shadow-lg">
                            <span className="text-white text-xs sm:text-sm">{selectedCounsellor.avatar}</span>
                          </div>
                          <div>
                            <p className="text-white text-xs sm:text-sm">{selectedCounsellor.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5 text-xs">
                              <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                              <span className="text-cream-100/80">{selectedCounsellor.rating}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Calendar */}
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-cream-100/90 text-sm">Select date</p>
                          <div className="flex items-center gap-2">
                            <motion.button
                              onClick={handlePrevMonth}
                              className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg transition-all"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <ChevronLeft className="w-4 h-4 text-cream-100" />
                            </motion.button>
                            <span className="text-cream-100 text-xs sm:text-sm min-w-[90px] text-center">
                              {currentMonth.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                            </span>
                            <motion.button
                              onClick={handleNextMonth}
                              className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg transition-all"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <ChevronRight className="w-4 h-4 text-cream-100" />
                            </motion.button>
                          </div>
                        </div>

                        <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                          <div className="grid grid-cols-7 gap-1 mb-1.5">
                            {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                              <div key={d} className="text-center text-cream-100/60 text-[11px] py-0.5">
                                {d}
                              </div>
                            ))}
                          </div>
                          <div className="grid grid-cols-7 gap-1">
                            {Array.from({ length: getDaysInMonth(currentMonth).startingDayOfWeek }).map((_, i) => (
                              <div key={`empty-${i}`} className="aspect-square" />
                            ))}

                            {Array.from({ length: getDaysInMonth(currentMonth).daysInMonth }).map((_, i) => {
                              const day = i + 1;
                              const past = isDatePast(day);
                              const selected = isSameDate(selectedDate, day);

                              return (
                                <motion.button
                                  key={day}
                                  onClick={() => handleDateSelect(day)}
                                  disabled={past}
                                  className={`aspect-square rounded-lg flex items-center justify-center text-xs transition-all ${
                                    past
                                      ? 'text-cream-100/30 cursor-not-allowed'
                                      : selected
                                      ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg'
                                      : 'text-white hover:bg-white/20'
                                  }`}
                                  whileHover={!past ? { scale: 1.1 } : {}}
                                  whileTap={!past ? { scale: 0.95 } : {}}
                                >
                                  {day}
                                </motion.button>
                              );
                            })}
                          </div>
                        </div>
                      </div>

                      {/* Time slots */}
                      {selectedDate && (
                        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                          <p className="text-cream-100/90 mb-2 text-sm">Select time</p>
                          <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                            {timeSlots.map((time) => (
                              <motion.button
                                key={time}
                                onClick={() => {
                                  setSelectedTime(time);
                                  setSelectedType(null);
                                }}
                                className={`px-3 py-2 rounded-lg text-xs sm:text-sm transition-all ${
                                  selectedTime === time
                                    ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg'
                                    : 'bg-white/10 text-cream-100 hover:bg-white/20 border border-white/10'
                                }`}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                              >
                                {time}
                              </motion.button>
                            ))}
                          </div>
                        </motion.div>
                      )}

                      {/* Session type */}
                      {selectedTime && (
                        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                          <p className="text-cream-100/90 mb-2 text-sm">Session type</p>
                          <div className="space-y-2">
                            <motion.button
                              onClick={() => setSelectedType('online')}
                              className={`w-full p-3 rounded-xl flex items-center gap-3 transition-all text-sm ${
                                selectedType === 'online'
                                  ? 'bg-gradient-to-r from-teal-400 to-teal-600 border-teal-400 shadow-lg'
                                  : 'bg-white/10 hover:bg-white/15 border border-white/20 hover:border-teal-400/60'
                              }`}
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <div
                                className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                                  selectedType === 'online'
                                    ? 'bg-white/20'
                                    : 'bg-gradient-to-br from-teal-400 to-teal-600'
                                }`}
                              >
                                <Video className="w-4 h-4 text-white" />
                              </div>
                              <div className="flex-1 text-left">
                                <p className="text-white text-xs sm:text-sm">Online Meet</p>
                                <p className="text-cream-100/60 text-[11px] sm:text-xs">
                                  Video call via Google Meet
                                </p>
                              </div>
                              <span className={selectedType === 'online' ? 'text-white' : 'text-teal-300'}>
                                ₹6,500
                              </span>
                            </motion.button>

                            <motion.button
                              onClick={() => setSelectedType('offline')}
                              className={`w-full p-3 rounded-xl flex items-center gap-3 transition-all text-sm ${
                                selectedType === 'offline'
                                  ? 'bg-gradient-to-r from-coral-400 to-coral-600 border-coral-400 shadow-lg'
                                  : 'bg-white/10 hover:bg-white/15 border border-white/20 hover:border-coral-400/60'
                              }`}
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <div
                                className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                                  selectedType === 'offline'
                                    ? 'bg-white/20'
                                    : 'bg-gradient-to-br from-coral-400 to-coral-600'
                                }`}
                              >
                                <MapPin className="w-4 h-4 text-white" />
                              </div>
                              <div className="flex-1 text-left">
                                <p className="text-white text-xs sm:text-sm">Offline Meet</p>
                                <p className="text-cream-100/60 text-[11px] sm:text-xs">
                                  In-person at MindMate Centre
                                </p>
                              </div>
                              <span className={selectedType === 'offline' ? 'text-white' : 'text-teal-300'}>
                                ₹8,000
                              </span>
                            </motion.button>
                          </div>
                        </motion.div>
                      )}

                      {selectedType && (
                        <motion.button
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          onClick={handleBookSession}
                          className="w-full mt-2 py-3.5 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg flex items-center justify-center gap-2 text-sm sm:text-base"
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
                          Book Session
                        </motion.button>
                      )}
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex flex-col items-center justify-center py-10"
                    >
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                        className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl flex items-center justify-center shadow-xl mb-4 sm:mb-6"
                      >
                        <User className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                      </motion.div>
                      <p className="text-cream-100/80 text-sm sm:text-base text-center">
                        Select a counsellor to start booking.
                      </p>
                    </motion.div>
                  )}
                </motion.div>
              </div>
            </div>
          ) : (
            // My Bookings
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {bookings.length === 0 ? (
                <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl p-8 sm:p-12 border border-white/10">
                  <div className="text-center">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-coral-400 to-coral-600 rounded-3xl flex items-center justify-center mx-auto mb-5 sm:mb-6 shadow-2xl">
                      <Calendar className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
                    </div>
                    <h2 className="text-white text-2xl sm:text-3xl mb-2 sm:mb-3">Your Bookings</h2>
                    <p className="text-cream-100/70 text-sm sm:text-lg mb-6 sm:mb-8">
                      You have not booked any sessions yet.
                    </p>
                    <motion.button
                      onClick={() => setActiveTab('book')}
                      className="px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg text-sm sm:text-base"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Book Your First Session
                    </motion.button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <h2 className="text-white text-2xl sm:text-3xl mb-4 sm:mb-6">
                    Your Bookings ({bookings.length})
                  </h2>
                  {bookings.map((b, index) => (
                    <motion.div
                      key={b.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.08 }}
                      className="bg-slate-900/60 backdrop-blur-xl rounded-2xl p-5 sm:p-6 border border-white/10 hover:border-white/30 hover:shadow-lg transition-all"
                    >
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="text-white text-lg sm:text-xl mb-1.5">{b.sessionName}</h3>
                          {b.description && (
                            <p className="text-cream-100/70 text-sm sm:text-base mb-3">{b.description}</p>
                          )}
                          <div className="flex items-center gap-2 mb-2 text-sm">
                            <User className="w-4 h-4 text-teal-400" />
                            <span className="text-cream-100/90">{b.counsellor}</span>
                          </div>

                          <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-cream-100/80">
                            <span className="flex items-center gap-1.5">
                              <Calendar className="w-4 h-4 text-coral-400" />
                              {b.date}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1.5">
                              <Clock className="w-4 h-4 text-coral-400" />
                              {b.time}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1.5">
                              {b.type === 'online' ? (
                                <Video className="w-4 h-4 text-teal-400" />
                              ) : (
                                <MapPin className="w-4 h-4 text-teal-400" />
                              )}
                              {b.type === 'online' ? 'Online' : 'Offline'}
                            </span>

                            {b.type === 'online' && b.meetLink && (
                              <span className="flex items-center gap-1.5 text-teal-300 underline cursor-pointer">
                                <Video className="w-4 h-4" />
                                <a href={b.meetLink} target="_blank" rel="noreferrer">
                                  Join Meet
                                </a>
                              </span>
                            )}

                            {b.type === 'offline' && (
                              <span className="text-cream-100/60 text-[11px] sm:text-xs">
                                Location details have been emailed (demo).
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="md:text-right">
                          <div className="inline-block px-4 py-2 bg-gradient-to-r from-teal-400/20 to-teal-600/20 border border-teal-400/30 rounded-xl">
                            <span className="text-teal-300 text-base sm:text-lg">
                              ₹{b.price.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </div>
      </main>

      {/* Booking dialog */}
      <AnimatePresence>
        {showBookingDialog && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowBookingDialog(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 15 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900/95 backdrop-blur-xl rounded-3xl p-6 sm:p-8 border border-white/20 max-w-md w-full shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <h3 className="text-white text-xl sm:text-2xl">Session Details</h3>
                <motion.button
                  onClick={() => setShowBookingDialog(false)}
                  className="p-2 hover:bg-white/10 rounded-xl transition-all"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X className="w-4 h-4 sm:w-5 sm:h-5 text-cream-100" />
                </motion.button>
              </div>

              <div className="space-y-4 sm:space-y-5 mb-5 sm:mb-6">
                <div>
                  <label className="text-cream-100/90 text-xs sm:text-sm mb-1.5 block">
                    Session name *
                  </label>
                  <input
                    type="text"
                    value={sessionName}
                    onChange={(e) => setSessionName(e.target.value)}
                    placeholder="e.g., Anxiety Management Session"
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-white/10 border border-white/20 rounded-xl text-sm sm:text-base text-white placeholder-cream-100/40 focus:border-teal-400 focus:outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="text-cream-100/90 text-xs sm:text-sm mb-1.5 block">
                    Description (optional)
                  </label>
                  <textarea
                    value={sessionDescription}
                    onChange={(e) => setSessionDescription(e.target.value)}
                    placeholder="Describe what you'd like to discuss..."
                    rows={3}
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-white/10 border border-white/20 rounded-xl text-sm sm:text-base text-white placeholder-cream-100/40 focus:border-teal-400 focus:outline-none transition-all resize-none"
                  />
                </div>

                <div className="bg-white/5 rounded-xl p-3 sm:p-4 border border-white/10 text-xs sm:text-sm">
                  <p className="text-cream-100/70 mb-2">Booking summary</p>
                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-cream-100/80">Counsellor:</span>
                      <span className="text-white">{selectedCounsellor?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-cream-100/80">Date:</span>
                      <span className="text-white">
                        {selectedDate?.toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-cream-100/80">Time:</span>
                      <span className="text-white">{selectedTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-cream-100/80">Type:</span>
                      <span className="text-white capitalize">{selectedType}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-white/10 mt-2">
                      <span className="text-cream-100/80">Total:</span>
                      <span className="text-teal-400">
                        ₹{selectedType === 'online' ? '6,500' : selectedType === 'offline' ? '8,000' : '--'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 sm:gap-3">
                <motion.button
                  onClick={() => setShowBookingDialog(false)}
                  className="flex-1 px-4 sm:px-6 py-2.5 sm:py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all border border-white/20 text-sm sm:text-base"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Cancel
                </motion.button>
                <motion.button
                  onClick={handleConfirmBooking}
                  disabled={!sessionName}
                  className={`flex-1 px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl transition-all text-sm sm:text-base ${
                    sessionName
                      ? 'bg-gradient-to-r from-teal-400 to-teal-600 text-white shadow-lg hover:shadow-xl'
                      : 'bg-slate-700/50 text-cream-100/50 cursor-not-allowed'
                  }`}
                  whileHover={sessionName ? { scale: 1.02 } : {}}
                  whileTap={sessionName ? { scale: 0.98 } : {}}
                >
                  Confirm Booking
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
