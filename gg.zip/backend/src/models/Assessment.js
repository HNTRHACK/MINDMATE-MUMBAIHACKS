import mongoose from "mongoose";

const assessmentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    phq9Answers: [{ type: Number }],
    gad7Answers: [{ type: Number }],
    phq9Score: { type: Number, required: true },
    gad7Score: { type: Number, required: true },
  },
  { timestamps: true }
);

export const Assessment = mongoose.model("Assessment", assessmentSchema);
