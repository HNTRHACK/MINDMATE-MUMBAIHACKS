import { createBrowserRouter } from "react-router-dom";
import { HomePage } from "../pages/HomePage";
import { LoginPage } from "../pages/LoginPage";
import { SignUpPage } from "../pages/SignUpPage";
import { AssessmentPage } from "../pages/AssessmentPage";
import { DashboardPage } from "../pages/DashboardPage";
import { ResourcesPage } from "../pages/ResourcesPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: HomePage,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/signup",
    Component: SignUpPage,
  },
  {
    path: "/assessment",
    Component: AssessmentPage,
  },
  {
    path: "/dashboard",
    Component: DashboardPage,
  },
  {
    path: "/resources",
    Component: ResourcesPage,
  },
]);
