import { motion } from 'motion/react';
import { Brain, Heart, ArrowRight, User } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';

export function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const demoUsers = [
    { name: 'Student Demo', email: 'student@demo.com' },
    { name: 'Counselor Demo', email: 'counselor@demo.com' },
    { name: 'Admin Demo', email: 'admin@demo.com' },
  ];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email,
          password
        })
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message || "Invalid credentials");
        return;
      }

      // Save token + user info locally
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      // Redirect to dashboard
      navigate("/dashboard");
    } catch (err) {
      console.error(err);
      alert("Login failed. Try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-[#ED6962] relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div 
        className="absolute top-20 left-10 w-96 h-96 bg-teal-400/40 rounded-full blur-3xl"
        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.7, 0.5] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute bottom-20 right-10 w-96 h-96 bg-coral-400/50 rounded-full blur-3xl"
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.6, 0.4, 0.6] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cream-100/20 rounded-full blur-3xl"
        animate={{ scale: [1, 1.1, 1], rotate: [0, 180, 360] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      />

      {/* Header */}
      <header className="relative z-10 px-6 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-coral-400 to-coral-600 rounded-xl flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-white text-xl">MindMate</span>
            </motion.div>
          </Link>

          <motion.div 
            className="flex items-center gap-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link to="/login">
              <button className="text-cream-100 hover:text-white transition-colors px-4 py-2 rounded-lg hover:bg-white/10">
                Login
              </button>
            </Link>
            <button className="bg-cream-50 text-slate-900 px-5 py-2 rounded-lg hover:bg-cream-100 transition-all hover:shadow-lg">
              Sign Up
            </button>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-6 py-8">
        <div className="max-w-md w-full">
          {/* Welcome Section */}
          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl mb-4 shadow-2xl"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Heart className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-white text-4xl mb-2">Welcome Back</h1>
            <p className="text-cream-100">Sign in to continue your mental health journey</p>
          </motion.div>

          {/* Login Form */}
          <motion.div
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10 mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-white text-2xl mb-2">Sign In</h2>
            <p className="text-cream-100/80 mb-6">Enter your credentials to access your account</p>

            <form className="space-y-5" onSubmit={handleLogin}>
              <div>
                <label className="text-cream-100 block mb-2">Email Address</label>
                <input
                  type="email"
                  placeholder="hello@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="text-cream-100 block mb-2">Password</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
              </div>

              <motion.button
                type="submit"
                className="w-full bg-gradient-to-r from-coral-400 to-coral-600 text-white py-4 rounded-xl shadow-lg hover:shadow-coral-500/50 transition-all flex items-center justify-center gap-2 group"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Sign In
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </form>

            <p className="text-center text-cream-100/60 mt-6">
              Don't have an account?{' '}
              <Link to="/signup">
                <button className="text-teal-400 hover:text-teal-300 transition-colors">
                  Create New Account
                </button>
              </Link>
            </p>
          </motion.div>

          {/* Quick Demo Access */}
          <motion.div
            className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="text-white text-xl mb-4">Quick Demo Access</h3>
            <div className="grid grid-cols-1 gap-3">
              {demoUsers.map((user, index) => (
                <motion.button
                  key={user.email}
                  className="px-5 py-3 rounded-xl bg-white/5 border border-white/10 text-cream-100 hover:bg-white/10 hover:border-teal-400/50 transition-all text-left flex items-center gap-3 group"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                  whileHover={{ x: 5 }}
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-lg flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <span>{user.name}</span>
                  <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </motion.button>
              ))}
            </div>
            <p className="text-cream-100/50 text-sm text-center mt-4">
              Click to explore demo credentials
            </p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
