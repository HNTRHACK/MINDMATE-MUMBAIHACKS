import { motion } from 'motion/react';
import { 
  Brain, Heart, MessageCircle, Calendar, Users, BookOpen, Bot, Video, 
  ArrowRight, Sparkles, User, TrendingUp, Award, Zap 
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

type SessionUI = {
  counselor: string;
  specialty: string;
  date: string;
  time: string;
  duration: string;
};

type ActivityItem = {
  text: string;
  time: string;
  icon: React.ComponentType<{ className?: string }>;
};

type GroupItem = {
  name: string;
  members: number;
  active: string;
  color: string;
};

export function DashboardPage() {
  const navigate = useNavigate();

  // default / fallback user name
  const [userName, setUserName] = useState<string>("Student");

  // fallback mock sessions
  const [upcomingSessions, setUpcomingSessions] = useState<SessionUI[]>([
    { counselor: "Dr. Sarah Johnson", specialty: "Anxiety Specialist", date: "Today", time: "2:00 PM", duration: "45 min" },
    { counselor: "Dr. Michael Chen", specialty: "Depression Therapy", date: "Tomorrow", time: "10:00 AM", duration: "60 min" },
    { counselor: "Dr. Emily Davis", specialty: "Stress Management", date: "Dec 3", time: "3:30 PM", duration: "45 min" }
  ]);

  const recentActivity: ActivityItem[] = [
    { text: "Joined 'Anxiety Support Group'", time: "2 hours ago", icon: Users },
    { text: "Completed Depression Screening", time: "1 day ago", icon: Award },
    { text: "Booked session with Dr. Johnson", time: "2 days ago", icon: Calendar }
  ];

  const userGroups: GroupItem[] = [
    { name: "Anxiety Support", members: 124, active: "32 online", color: "from-teal-400 to-teal-600" },
    { name: "Student Wellness", members: 89, active: "18 online", color: "from-coral-400 to-coral-600" },
    { name: "Mindfulness Circle", members: 156, active: "45 online", color: "from-indigo-400 to-indigo-600" }
  ];

  const quickStats = [
    { label: "Sessions", value: String(upcomingSessions.length), change: "+2", icon: Video, color: "from-teal-400 to-teal-600" },
    { label: "Groups", value: "3", change: "+1", icon: Users, color: "from-coral-400 to-coral-600" },
    { label: "Streak", value: "7d", change: "New!", icon: Zap, color: "from-indigo-400 to-indigo-600" }
  ];

  useEffect(() => {
    // Check auth
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");

    if (!token || !userStr) {
      navigate("/login");
      return;
    }

    try {
      const user = JSON.parse(userStr);
      if (user?.fullName) {
        setUserName(user.fullName);
      }
    } catch {
      // ignore JSON errors, keep default name
    }

    // Try to load real sessions from backend
    const loadSessions = async () => {
      try {
        const res = await fetch("http://localhost:5000/api/sessions/my", {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (!res.ok) return; // keep mock data

        const data = await res.json();

        // Expecting array of sessions from backend
        if (Array.isArray(data) && data.length > 0) {
          const mapped: SessionUI[] = data.map((s: any) => ({
            counselor: s.counselorName || "Counselor",
            specialty: s.specialty || "Therapy Session",
            date: s.date || "Upcoming",
            time: s.time || "",
            duration: (s.durationMinutes ? `${s.durationMinutes} min` : "45 min")
          }));
          setUpcomingSessions(mapped);
        }
      } catch (err) {
        console.error("Failed to load sessions:", err);
        // keep fallback sessions
      }
    };

    loadSessions();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-600 via-indigo-700 to-[#ED6962] relative overflow-hidden">
      {/* Animated background circles */}
      <motion.div 
        className="absolute top-32 right-20 w-[500px] h-[500px] bg-teal-400/30 rounded-full blur-3xl"
        animate={{ scale: [1, 1.3, 1], x: [0, 50, 0], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute bottom-32 left-20 w-[600px] h-[600px] bg-coral-400/40 rounded-full blur-3xl"
        animate={{ scale: [1.2, 1, 1.2], y: [0, -50, 0], opacity: [0.4, 0.6, 0.4] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div 
        className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-indigo-400/20 rounded-full blur-3xl"
        animate={{ scale: [1, 1.4, 1], rotate: [0, 180, 360], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Header */}
      <header className="relative z-10 px-8 py-6">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link to="/" className="flex items-center gap-3">
              <motion.div
                initial={{ opacity: 0, rotate: -180 }}
                animate={{ opacity: 1, rotate: 0 }}
                transition={{ duration: 0.8, type: "spring" }}
                className="flex items-center gap-3"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <span className="text-white text-2xl">MindMate</span>
              </motion.div>
            </Link>

            <motion.div 
              className="flex items-center gap-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <nav className="flex items-center gap-2 bg-slate-900/40 backdrop-blur-xl rounded-2xl p-2 border border-white/10">
                <motion.button
                  className="px-5 py-2.5 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <TrendingUp className="w-4 h-4" />
                  Dashboard
                </motion.button>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Users className="w-4 h-4" />
                  Community
                </motion.button>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Calendar className="w-4 h-4" />
                  Book Session
                </motion.button>
                <Link to="/resources">
                  <motion.button
                    className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <BookOpen className="w-4 h-4" />
                    Resources
                  </motion.button>
                </Link>
                <motion.button
                  className="px-5 py-2.5 text-cream-100 hover:text-white hover:bg-white/10 rounded-xl transition-all flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Bot className="w-4 h-4" />
                  AI Chat
                </motion.button>
              </nav>
              <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center shadow-lg cursor-pointer border-2 border-white/20">
                <span className="text-white">
                  {userName?.[0]?.toUpperCase() || 'U'}
                </span>
              </div>
            </motion.div>
          </div>

          {/* Greeting Section - Horizontal */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-gradient-to-r from-slate-900/50 to-slate-900/30 backdrop-blur-xl rounded-3xl p-8 border border-white/10 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <motion.div 
                  className="w-20 h-20 bg-gradient-to-br from-coral-400 via-coral-500 to-coral-600 rounded-2xl flex items-center justify-center shadow-xl"
                  animate={{ rotate: [0, 5, 0, -5, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <Heart className="w-10 h-10 text-white" />
                </motion.div>
                <div>
                  <h1 className="text-white text-4xl mb-2">Hey there, {userName}! 👋</h1>
                  <p className="text-cream-100/80 text-lg">Ready to continue your mental wellness journey?</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                {quickStats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="bg-white/10 backdrop-blur-sm rounded-2xl px-6 py-4 border border-white/20"
                  >
                    <div className="flex items-center gap-3 mb-1">
                      <div className={`w-10 h-10 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                        <stat.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-white text-2xl">{stat.value}</p>
                        <p className="text-cream-100/70 text-xs">{stat.label}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Main Content - Asymmetric Layout */}
      <main className="relative z-10 px-8 py-6">
        <div className="max-w-[1600px] mx-auto">
          <div className="grid grid-cols-12 gap-6">
            {/* Left Column */}
            <div className="col-span-12 lg:col-span-8 space-y-6">
              {/* Upcoming Sessions */}
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/10"
              >
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-white text-3xl mb-1">Upcoming Sessions</h2>
                    <p className="text-cream-100/70">Your scheduled counseling appointments</p>
                  </div>
                  <motion.button
                    className="px-6 py-3 bg-gradient-to-r from-coral-400 to-coral-600 text-white rounded-2xl flex items-center gap-2 shadow-lg hover:shadow-coral-500/50"
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Book New
                    <Calendar className="w-5 h-5" />
                  </motion.button>
                </div>

                <div className="space-y-4">
                  {upcomingSessions.map((session, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="flex items-center justify-between p-5 bg-gradient-to-r from-white/10 to-white/5 rounded-2xl border border-white/20 hover:border-teal-400/50 transition-all group"
                      whileHover={{ x: 5 }}
                    >
                      <div className="flex items-center gap-5">
                        <div className="relative">
                          <div className="w-16 h-16 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center shadow-xl">
                            <User className="w-8 h-8 text-white" />
                          </div>
                          {index === 0 && (
                            <motion.div 
                              className="absolute -top-2 -right-2 w-6 h-6 bg-teal-400 rounded-full flex items-center justify-center"
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ duration: 2, repeat: Infinity }}
                            >
                              <span className="text-white text-xs">!</span>
                            </motion.div>
                          )}
                        </div>
                        <div>
                          <p className="text-white text-lg mb-1">{session.counselor}</p>
                          <p className="text-teal-300 text-sm mb-1">{session.specialty}</p>
                          <div className="flex items-center gap-4 text-cream-100/70 text-sm">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {session.date}
                            </span>
                            <span>•</span>
                            <span>{session.time}</span>
                            <span>•</span>
                            <span>{session.duration}</span>
                          </div>
                        </div>
                      </div>
                      <motion.button 
                        className="px-8 py-3 bg-gradient-to-r from-teal-400 to-teal-600 text-white rounded-xl shadow-lg group-hover:shadow-teal-500/50 transition-all"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Join Now
                      </motion.button>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Quick Actions */}
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <h2 className="text-white text-3xl mb-4">Quick Access</h2>
                <div className="grid grid-cols-2 gap-5">
                  <motion.button
                    className="bg-gradient-to-br from-teal-500/30 to-teal-600/20 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-teal-400/30 hover:border-teal-400/60 transition-all text-left group relative overflow-hidden"
                    whileHover={{ scale: 1.02, y: -4 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <motion.div 
                      className="absolute top-0 right-0 w-32 h-32 bg-teal-400/20 rounded-full blur-2xl"
                      animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
                      transition={{ duration: 3, repeat: Infinity }}
                    />
                    <div className="relative z-10">
                      <div className="w-14 h-14 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl flex items-center justify-center mb-4 shadow-xl">
                        <Bot className="w-7 h-7 text-white" />
                      </div>
                      <h3 className="text-white text-xl mb-2">AI Mental Health Assistant</h3>
                      <p className="text-cream-100/80">Get instant support and guidance 24/7</p>
                      <ArrowRight className="w-6 h-6 text-teal-300 mt-3 group-hover:translate-x-2 transition-transform" />
                    </div>
                  </motion.button>

                  <Link to="/resources">
                    <motion.button
                      className="bg-gradient-to-br from-coral-500/30 to-coral-600/20 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-coral-400/30 hover:border-coral-400/60 transition-all text-left group relative overflow-hidden w-full"
                      whileHover={{ scale: 1.02, y: -4 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <motion.div 
                        className="absolute top-0 right-0 w-32 h-32 bg-coral-400/20 rounded-full blur-2xl"
                        animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
                        transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
                      />
                      <div className="relative z-10">
                        <div className="w-14 h-14 bg-gradient-to-br from-coral-400 to-coral-600 rounded-2xl flex items-center justify-center mb-4 shadow-xl">
                          <BookOpen className="w-7 h-7 text-white" />
                        </div>
                        <h3 className="text-white text-xl mb-2">Wellness Resources</h3>
                        <p className="text-cream-100/80">Explore articles, videos, and tools</p>
                        <ArrowRight className="w-6 h-6 text-coral-300 mt-3 group-hover:translate-x-2 transition-transform" />
                      </div>
                    </motion.button>
                  </Link>
                </div>
              </motion.div>
            </div>

            {/* Right Column */}
            <div className="col-span-12 lg:col-span-4 space-y-6">
              {/* Communities */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/10"
              >
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-white text-2xl">Your Communities</h2>
                  <Users className="w-6 h-6 text-teal-400" />
                </div>
                <div className="space-y-4">
                  {userGroups.map((group, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      className="p-4 bg-gradient-to-br from-white/10 to-white/5 rounded-2xl border border-white/20 hover:border-white/40 transition-all cursor-pointer group"
                      whileHover={{ scale: 1.03 }}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-12 h-12 bg-gradient-to-br ${group.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg`}>
                          <Users className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white mb-1">{group.name}</p>
                          <p className="text-cream-100/70 text-sm">{group.members} members</p>
                          <div className="flex items-center gap-2 mt-2">
                            <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse"></div>
                            <p className="text-teal-300 text-xs">{group.active}</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <motion.button 
                  className="w-full mt-5 py-3 bg-gradient-to-r from-indigo-400 to-indigo-600 text-white rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Explore More
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.7 }}
                className="bg-slate-900/40 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/10"
              >
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-white text-2xl">Activity Feed</h2>
                  <Sparkles className="w-6 h-6 text-coral-400" />
                </div>
                <div className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.8 + index * 0.1 }}
                      className="flex items-start gap-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-all"
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center flex-shrink-0">
                        <activity.icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="text-cream-100 text-sm mb-1">{activity.text}</p>
                        <p className="text-cream-100/50 text-xs">{activity.time}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
