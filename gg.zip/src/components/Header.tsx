import { motion } from 'motion/react';
import { Brain } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Header() {
  return (
    <header className="relative z-10 px-6 py-5">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/">
          <motion.div 
            className="flex items-center gap-3"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="w-10 h-10 bg-gradient-to-br from-coral-400 to-coral-600 rounded-xl flex items-center justify-center shadow-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-white text-xl">MindMate</span>
          </motion.div>
        </Link>

        <motion.div 
          className="flex items-center gap-4"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link to="/login">
            <button className="text-cream-100 hover:text-white transition-colors px-4 py-2 rounded-lg hover:bg-white/10">
              Login
            </button>
          </Link>
          <Link to="/signup">
            <button className="bg-cream-50 text-slate-900 px-5 py-2 rounded-lg hover:bg-cream-100 transition-all hover:shadow-lg">
              Sign Up
            </button>
          </Link>
        </motion.div>
      </div>
    </header>
  );
}
